/* Wow, tellement un beau spot pour écrire du JS */
/* mot de passe: Louis-Marcel OtsaMBA */